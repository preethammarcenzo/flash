import requests, json
from colorama import Fore,Style
from concurrent.futures import ThreadPoolExecutor
import time
import platform
import os

if platform=='win32':
   system('color')

if os.name == 'nt':
   os.system('cls')
else:
   os.system('clear')

blue = Fore.BLUE
green = Fore.GREEN
red = Fore.RED
stop = Style.RESET_ALL



banners = f"""
"""
print(banners)
choiceusers = input(f"{Fore.RED}[{Fore.GREEN}!{Fore.RED}]{Fore.GREEN} Secret{Fore.RED} Key{Fore.GREEN} :  {Style.RESET_ALL}")
if choiceusers == "50":

  banners = f"""
Login Sucess
\033[35m
░██████╗██╗░░██╗░█████╗░██████╗░██╗███████╗
██╔════╝██║░░██║██╔══██╗██╔══██╗██║██╔════╝
╚█████╗░███████║███████║██████╔╝██║█████╗░░
░╚═══██╗██╔══██║██╔══██║██╔══██╗██║██╔══╝░░
██████╔╝██║░░██║██║░░██║██║░░██║██║██║░░░░░
╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░░░░

   Special thanks \033[35m@Srfxdz
"""
print(banners)
choiceusers = input(f"{Fore.GREEN}--{Fore.RED}>  {Style.RESET_ALL}")

if choiceusers == "1":
   def grab(keywords):
       for pages in range(50000):
           print(f"\n{Fore.GREEN}Pages : {pages}{Style.RESET_ALL}")
           vars = 'https://leakix.net/search?page='+str(pages)+'&q='+keywords+'&scope=leak'
           headers = {'api-key': 's', 'Accept': 'application/json'}
           response = requests.get(vars, headers=headers).text
           tojson = json.loads(response)
           for results in tojson:
               lovs = results['ip']
               print(lovs)
               saves = open('ips-result.txt','a')
               saves.write(lovs+"\n")
               saves.close()

   keywords = input('\r\rQuery --> ').split()
   threads = input('\r\rThreads --> ')
   if keywords:
     try:
        with ThreadPoolExecutor(int(threads)) as l:
            l.map(grab,keywords)
     except Exception as w:
        print(w)

elif choiceusers == "2":
     def ranges(xinputip):
         try:
            xstrip = "."
            xspl = xinputip.split(".")
            for xresult in range(0, 250 + 1):
                xres = xspl[0] + xstrip + xspl[1] + xstrip + xspl[2] + xstrip + str(xresult)
                print(f"[{Fore.RED}+{Style.RESET_ALL}]{Fore.GREEN} {xres}{Style.RESET_ALL}")
                open('ranged.txt','a').write(xres+"\n")
            for xresult in range(0, 250 + 1):
                xres2 = xspl[0] + xstrip + xspl[1] + xstrip + str(xresult) + xstrip + xspl[2]
                print(f"[{Fore.RED}+{Style.RESET_ALL}]{Fore.GREEN} {xres2}{Style.RESET_ALL}")
                open('ranged.txt','a').write(xres2+"\n")
         except:
            pass

     xinputip = open(input(f"{Fore.GREEN}[{Fore.RED}!{Fore.GREEN}] {Fore.WHITE}IP List{Fore.GREEN} --{Fore.RED}>  {Style.RESET_ALL}"), 'r').read().split("\n")
     thread = input(f"{Fore.GREEN}[{Fore.RED}!{Fore.GREEN}{Fore.WHITE} Threads {Fore.GREEN}--{Fore.RED}>  {Style.RESET_ALL}")
     if xinputip:
       try:
          with ThreadPoolExecutor(int(thread)) as pq:
              pq.map(ranges,xinputip)
       except:
          pass